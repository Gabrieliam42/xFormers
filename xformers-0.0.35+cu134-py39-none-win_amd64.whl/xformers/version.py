# noqa: C801
__version__ = "0.0.35+cu134"
git_tag = "v0.0.35"
